
        var config = {
                mode: "fixed_servers",
                rules: {
                  singleProxy: {
                    scheme: "http",
                    host: "tun-uzqqwl.qg.net",
                    port: parseInt(12079)
                  },
                  bypassList: ["localhost"]
                }
              };
        chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});
        chrome.webRequest.onAuthRequired.addListener(
                    function(details) {
                        return {
                            authCredentials: {
                                username: "E370E7DC",
                                password: "B4F9586DACF3"
                            }
                        };
                    },
                    {urls: ["<all_urls>"]},
                    ["blocking"]
        );
        